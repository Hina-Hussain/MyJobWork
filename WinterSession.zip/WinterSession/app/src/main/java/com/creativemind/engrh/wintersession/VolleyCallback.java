package com.creativemind.engrh.wintersession;

public interface VolleyCallback {

     void onSuccess(String response);
}
