package com.creativemind.engrh.wintersession;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class RegisterActivity extends AppCompatActivity {

    private final String registerURL = "http://engrhina15.000webhostapp.com/register.php";
    private EditText name,email,passw,conform,mobno;
    private TextView textLogin;
    private Button register;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name =    findViewById(R.id.name);
        email =  findViewById(R.id.email);
        passw = findViewById(R.id.passw);
        conform = findViewById(R.id.conform_pass);
        mobno = findViewById(R.id.mobno);
        register = findViewById(R.id.register);
        textLogin = findViewById(R.id.loginText);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RegisterActivity.this,TestService.class));
                finish();
            }
        });

    }
}
