package com.creativemind.engrh.wintersession;

import android.app.ProgressDialog;
import android.content.Context;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

public class WebServiceCall {
    private Context context;
    private static final String url = "http://192.168.1.104:8080/Grocery/rest/user/getDistrict";
    private static String result = null;
    private ProgressDialog progressDialog;
    private ProgressBar progressBar;
    public WebServiceCall(Context context) {
        this.context = context;
        progressDialog = new ProgressDialog(context);

    }

    public void getAllDist(final VolleyCallback callback)
    {
        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        progressDialog.dismiss();

                        if(response!=null)
                           callback.onSuccess(response);
                        //Toast.makeText(context,"In response method: "+response,Toast.LENGTH_SHORT).show();

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context,error.getMessage(),Toast.LENGTH_SHORT).show();
                    }
                }
        );
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);

    }
}
