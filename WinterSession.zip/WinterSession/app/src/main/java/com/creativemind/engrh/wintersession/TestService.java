package com.creativemind.engrh.wintersession;

import android.app.Activity;
import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class TestService extends AppCompatActivity
        //implements VolleyCallback
        {

    private TextView text;
    private Spinner spinner;
    private WebServiceCall webService;
    private String result="";
    private ProgressDialog progressDialog;
    private Activity activity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_service);
        text =    findViewById(R.id.text);
        spinner = findViewById(R.id.spiner);
        webService = new WebServiceCall(this);
        //progressDialog = new ProgressDialog(this);
        activity = this;
        webService.getAllDist(new VolleyCallback() {
            @Override
            public void onSuccess(String response) {
                result = response;
                String str  = result.replaceAll("\\[|\\]", "");
                String []arr = str.split(",");
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(activity,android.R.layout.simple_spinner_dropdown_item,arr);
               adapter.setDropDownViewResource(R.layout.spiner_item);
                spinner.setAdapter(adapter);
            }
        });



    }

/*    @Override
    public void onSuccess(String response) {

        result = response;
        String str  = result.replaceAll("\\[|\\]", "");
        String []arr = str.split(",");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,arr);
        spinner.setAdapter(adapter);

    }*/
}
